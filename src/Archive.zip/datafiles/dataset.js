//Setting the contact data for the skill
var contacts = [
		{
			"fname":"dave",
			"lname":"isbitsky",
			"bio": "is Chief Alexa evangelist",
			"city": "philadephia",
			"twitter":"thedavedev",
			"prettyTwitter":"the dave dev",
			"github":"disbitski",
			"linkedin":"https://www.linkedin.com/in/davidisbitski",
			"email":"isbitski@amazon.com"
		},
		{
			"fname":"amit",
			"lname":"jotwani",
			"bio": "is Alexa Voice Service evangelist",
			"city":"new york",
			"twitter":"amit",
			"prettyTwitter":"amit",
			"github":"ajot",
			"linkedin":"https://www.linkedin.com/in/ajotwani",
			"email":"ajot@amazon.com"
		},
		{
			"fname":"paul",
			"lname":"cutsinger",
			"bio": "is Chief Alexa evangelist",
			"city":"seattle",
			"twitter":"@paulcutsinger",
			"prettyTwitter":"paul cutsinger",
			"github":"paulcutsinger",
			"linkedin":"https://www.linkedin.com/in/paulcutsinger",
			"email":"cutsinge@amazon.com"
		},
		{
			"fname":"jeff",
			"lname":"blankenburg",
			"bio": "is Alexa evangelist",
			"city":"ohio",
			"twitter":"jeffblankenburg",
			"prettyTwitter":"jeff blankenburg",
			"github":"jeffblankenburg",
			"linkedin":"https://www.linkedin.com/in/paulcutsinger",
			"email":"jeffblan@amazon.com"
		},
		{
			"fname":"rob",
			"lname":"mccauley",
			"bio": "is Alexa evangelist",
			"city":"boston",
			"twitter":"robmccauley",
			"prettyTwitter":"rob mccauley",
			"github":"robm26",
			"linkedin":"https://www.linkedin.com/in/robm26",
			"email":"mccaul@amazon.com"
		},
		{
			"fname":"memo",
			"lname":"doring",
			"bio": "is Alexa evangelist",
			"city":"seattle",
			"twitter":"memodoring",
			"prettyTwitter":"memo doring",
			"github":"memodoring",
			"linkedin":"https://www.linkedin.com/in/guillermodoring",
			"email":"doringm@amazon.com"
		}
	]
module.exports = contacts;
